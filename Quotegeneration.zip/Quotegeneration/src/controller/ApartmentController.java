package controller;
 
import java.io.IOException;
 
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
 
import services.ApartmentService;
 
 
 
public class ApartmentController extends HttpServlet
{
 
	public  void doGet(HttpServletRequest request,HttpServletResponse response) 
	   throws ServletException,IOException 
	{
		RequestDispatcher rd = null;
		RequestDispatcher req = null;
		String apartmentSqft="";
		 String numberofSprinklers="";
		 String buildYear="";
		 String propertyDamage="";
		 String bodilyInjuryLimit="";
		 String numberofFloors="";
		 String numberofFireExits="";
		 String assetTheftLimit="";
 
		 int account_number=0;
		String business_segment="";
 
 
		apartmentSqft=request.getParameter("ApartmentSqft");
 
		numberofSprinklers=request.getParameter("NumberofSprinklers");
 
		buildYear=request.getParameter("BuildYear");
		propertyDamage=request.getParameter("PropertyDamage");
 
		bodilyInjuryLimit=request.getParameter("BodilyInjuryLimit");
		numberofFloors=request.getParameter("NumberofFloors");
		numberofFireExits=request.getParameter("NumberofFireExits");
		assetTheftLimit=request.getParameter("AssetTheftLimit");
 
 
		 String account_number1=request.getParameter("account_number");
		 account_number=Integer.parseInt(account_number1);
 
 
 
 
 
 
 
 
 
 
 
			/*String insured_zip1=request.getParameter("insured_zip");
			insured_zip=Integer.parseInt(insured_zip1);*/
		ApartmentService bookService = new ApartmentService();
 
 
 
		   int updateCount = bookService.addStudentService(apartmentSqft,numberofSprinklers,buildYear,propertyDamage,bodilyInjuryLimit,numberofFloors,numberofFireExits,assetTheftLimit,account_number);
 
				System.out.println("inserted "+updateCount+" record   Success");
 
				if (updateCount==1)
				{
					rd = request.getRequestDispatcher("/Thanks.jsp");	
 
				} else 
				{
					rd = request.getRequestDispatcher("/error.jsp");	
				}
				rd.forward(request, response);
			}
 
 
 
}