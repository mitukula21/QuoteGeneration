package controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import services.AccountService;
import services.BusinessService;

public class BusinessController extends HttpServlet
{
	
	public  void doGet(HttpServletRequest request,HttpServletResponse response) 
	   throws ServletException,IOException 
	{
		RequestDispatcher rd = null;
		RequestDispatcher req = null;
		String vehicletype="";
		 String vehiclemy="";
		 String vehiclemodel="";
		 String dailycd="";
		 String servicecenter="";
		 String limit="";
		 String limit2="";
		 int account_number=0;
		String business_segment="";
	
		
		vehicletype=request.getParameter("vehicletype");
		 
		 vehiclemy=request.getParameter("vehiclemy");
		 
		 vehiclemodel=request.getParameter("vehiclemodel");
		 dailycd=request.getParameter("dailycd");
		 servicecenter=request.getParameter("servicecenter");
		 limit=request.getParameter("limit");
		 limit2=request.getParameter("limit2");
		 String account_number1=request.getParameter("account_number");
		 account_number=Integer.parseInt(account_number1);
		
		 
		
		 
		 
		 
		 
		 
		 
		 
		 
			/*String insured_zip1=request.getParameter("insured_zip");
			insured_zip=Integer.parseInt(insured_zip1);*/
		 BusinessService bookService = new BusinessService();
			
			
			
		   int updateCount = bookService.addStudentService(vehicletype,vehiclemy,vehiclemodel,dailycd,servicecenter,limit,limit2,account_number);
				
				System.out.println("inserted "+updateCount+" record   Success");
				
				if (updateCount==1)
				{
					rd = request.getRequestDispatcher("/Thanks.jsp");	
					
				} else 
				{
					rd = request.getRequestDispatcher("/error.jsp");	
				}
				rd.forward(request, response);
			}
		 


}