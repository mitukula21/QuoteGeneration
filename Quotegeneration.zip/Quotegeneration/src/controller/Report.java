package controller;




	import java.io.IOException;
	import java.io.PrintWriter;
	import java.sql.Connection;
	import java.sql.DriverManager;
	import java.sql.PreparedStatement;
	import java.sql.ResultSet;

	import javax.servlet.ServletException;
	import javax.servlet.annotation.WebServlet;
	import javax.servlet.http.HttpServlet;
	import javax.servlet.http.HttpServletRequest;
	import javax.servlet.http.HttpServletResponse;

	@WebServlet("/Report")
	public class Report extends HttpServlet
	{
		private static final long serialVersionUID = 1L;
	 
	    public Report() {
	        super();
	        // TODO Auto-generated constructor stub
	    }
	 
		/*protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
			// TODO Auto-generated method stub
			response.getWriter().append("Served at: ").append(request.getContextPath());
		}*/
	 
		protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
			// TODO Auto-generated method stub
			//doGet(request, response);
			response.setContentType("text/html");
			PrintWriter out = response.getWriter();
	 
			/*String ID = request.getParameter("id");
			int id = Integer.parseInt(ID);*/
			String business_segment="";
			 business_segment=request.getParameter("business_segment");
			
			try { 
				//String page = request.getParameter("business_segment");
				  if(request.getParameter("business_segment").equals("BusinessAuto"))
			        {
				Class.forName("oracle.jdbc.OracleDriver");
			
				Connection con = DriverManager.getConnection("jdbc:oracle:thin:"+"@10.219.34.3:1521/orcl","trg629","training629");
				PreparedStatement ps = con.prepareStatement("select accountcreation.insured_name,businessauto1.question_id,"
						+ "businessauto1.account_number from businessauto1 "
						+ "inner join accountcreation on "
						+ "accountcreation.account_number=businessauto1.account_number");
				ResultSet rs = ps.executeQuery();
				
				out.println("<html>" + 
						"<head></head>" + 
						"<body>" + 
						"<table border='1'>" + 
						"<tr>" + 
						"<th>InsuredName: " + "</th><th>Policy_Id:</th><th>Account_Number:</th></tr>");
				
				while (rs.next())
				{
					
					out.println("<tr><td>"+rs.getString(1)+"</td><td>"+ rs.getInt(2) +"</td><td>"+ rs.getInt(3)+"</td></tr>");		
					
				}
				out.println("</table>" + "</body>" + "</html>");
				out.println("<form action=\"Fetch\" method=\"post\">\r\n" + 
						" Enter The Account Number::    <input type=\"text\" name=\"id\"> <br>\r\n" + 
						"		<input type=\"submit\" value=\"search\">\r\n" + 
						"</form>");
				out.println("</br></br><a href='Index.jsp'>Return to Home</a>");
			    }
				  else if(request.getParameter("business_segment").equals("Restaurant"))
			        {
					  Class.forName("oracle.jdbc.OracleDriver");
						
						Connection con = DriverManager.getConnection("jdbc:oracle:thin:"+"@10.219.34.3:1521/orcl","trg629","training629");
				PreparedStatement ps1 = con.prepareStatement("select accountcreation.insured_name,restaurant.question_id,restaurant.account_number from restaurant inner join accountcreation on accountcreation.account_number=restaurant.account_number");
				ResultSet rs1 = ps1.executeQuery();
				out.println("<html>" + 
						"<head></head>" + 
						"<body>" + 
						"<table border='1'>" + 
						"<tr>" + 
						"<th>InsuredName: " + "</th><th>Policy_Id:</th><th>Account_Number:</th></tr>");
				while (rs1.next()) 
				{
					
					
					out.println("<tr><td>"+rs1.getString(1) +"          "+
							"</td><td>"+ rs1.getInt(2) +        "</td><td>"+ rs1.getInt(3)+        "</td></tr>");
					
				}
				out.println("</table>" + "</body>" + "</html>");
				out.println("<form action=\"Fetch2\" method=\"post\">\r\n" + 
						"		Enter The Account Number:    <input type=\"text\" name=\"id\"> <br>\r\n" + 
						"		<input type=\"submit\" value=\"search\">\r\n" + 
						"</form>");
				out.println("</br></br><a href='Index.jsp'>Return to Home</a>");
			        }
				  else if(request.getParameter("business_segment").equals("Apartment"))
			        {
					  Class.forName("oracle.jdbc.OracleDriver");
						
						Connection con = DriverManager.getConnection("jdbc:oracle:thin:"+"@10.219.34.3:1521/orcl","trg629","training629");
				PreparedStatement ps2 = con.prepareStatement("select accountcreation.insured_name,apartment.question_id,apartment.account_number from apartment inner join accountcreation on accountcreation.account_number=apartment.account_number");
				ResultSet rs2 = ps2.executeQuery();
				out.println("<html>" + 
						"<head></head>" + 
						"<body>" + 
						"<table border='1'>" + 
						"<tr>" + 
						"<th>InsuredName: " + "</th><th>Policy_Id:</th><th>Account_Number:</th></tr>");
				while (rs2.next())
				{
					out.println("<tr><td>"+rs2.getString(1)+"</td><td>"+ rs2.getInt(2) +"</td><td>"+ rs2.getInt(3)+"</td></tr>");	
					
				}
				out.println("</table>" + "</body>" + "</html>");
				out.println("<form action=\"Fetch3\" method=\"post\">\r\n" + 
						"Enter The Account Number :    <input type=\"text\" name=\"id\"> <br>\r\n" + 
						"		<input type=\"submit\" value=\"search\">\r\n" + 
						"</form>");
				out.println("</br></br><a href='Index.jsp'>Return to Home</a>");
			    }
				  else if(request.getParameter("business_segment").equals("General_Merchant"))
			        {
					  Class.forName("oracle.jdbc.OracleDriver");
						
						Connection con = DriverManager.getConnection("jdbc:oracle:thin:"+"@10.219.34.3:1521/orcl","trg629","training629");
				  
				
				PreparedStatement ps3 = con.prepareStatement("select accountcreation.insured_name,general_merchant.question_id,general_merchant.account_number from general_merchant inner join accountcreation on accountcreation.account_number=general_merchant.account_number");
				ResultSet rs3 = ps3.executeQuery();
				out.println("<html>" + 
						"<head></head>" + 
						"<body>" + 
						"<table border='1'>" + 
						"<tr>" + 
						"<th>InsuredName: " + "</th><th>Policy_Id:</th><th>Account_Number:</th></tr>");
				while (rs3.next())
				{
					out.println("<tr><td>"+rs3.getString(1)+"</td><td>"+ rs3.getInt(2) +"</td><td>"+ rs3.getInt(3)+"</td></tr>");
					
				}
				out.println("</table>" + "</body>" + "</html>");
				out.println(" <form action=\"Fetch4\" method=\"post\">\r\n" + 
						"Enter The Account Number :    <input type=\"text\" name=\"id\"> <br>\r\n" + 
						"		<input type=\"submit\" value=\"search\">\r\n" + 
						"</form>\r\n" + 
						"");
				out.println("</br></br><a href='Index.jsp'>Return to Home</a>");
				
			       }
				
				 
				
			} 
			
			
			catch (Exception e) {
				e.printStackTrace();
			} finally {
				out.close();
			}
			System.out.println("retrieved data");
		
		}
	 
	}


