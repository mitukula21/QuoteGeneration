package controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;




@WebServlet("/Fetch4")
public class Fetch4 extends HttpServlet
{
	private static final long serialVersionUID = 1L;
 
    public Fetch4() {
        super();
        // TODO Auto-generated constructor stub
    }
 
	/*protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}*/
 
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//doGet(request, response);
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
 
		String ID = request.getParameter("id");
		int id = Integer.parseInt(ID);
        
		try { 
			Class.forName("oracle.jdbc.OracleDriver");
		
			Connection con = DriverManager.getConnection("jdbc:oracle:thin:"+"@10.219.34.3:1521/orcl","trg629","training629");
			PreparedStatement ps = con.prepareStatement("select accountcreation.insured_name,accountcreation.insured_street,\r\n" + 
					"accountcreation.insured_city,accountcreation.insured_state,\r\n" + 
					"accountcreation.insured_zip,accountcreation.business_segment,\r\n" + 
					"accountcreation.account_number,general_merchant.question_id,\r\n" + 
					"general_merchant.q1,general_merchant.businesstype,general_merchant.q2,\r\n" + 
					"general_merchant.assetvalue,general_merchant.q3,general_merchant.inflammableobjects,\r\n" + 
					"general_merchant.q4,general_merchant.popertysize,general_merchant.q5,\r\n" + 
					"general_merchant.bodilyinjury,general_merchant.q6,general_merchant.propertydamage,\r\n" + 
					"general_merchant.q7,general_merchant.assettheftlimit,general_merchant.q8,general_merchant.liablitycoverage from accountcreation \r\n" + 
					"full outer join general_merchant on accountcreation.account_number=general_merchant.account_number where general_merchant.account_number=?");
PreparedStatement ps1 = con.prepareStatement("select sum(BUSINESSTYPE+ASSETVALUE+INFLAMMABLEOBJECTS+POPERTYSIZE+BODILYINJURY+PROPERTYDAMAGE+ASSETTHEFTLIMIT+LIABLITYCOVERAGE) as sum from general_merchant where account_number=?");
			ps.setInt(1, id);
			ps1.setInt(1, id);
			
 
			ResultSet rs = ps.executeQuery();
 
			while (rs.next()) {
				out.println(
						"<html>" + 
								"<head></head>" + 
								"<body>" + 
								"<table border='1'>" + 
								"<tr>" + 
								"<td>InsuredName: " + "</td><td colspan='3'>"+rs.getString(1) +"</td>"+"</tr>"+
								"<tr><td></br> insured Street: "+ "</td><td colspan='3'>"+ rs.getString(2) +"</td>"+"</tr>"+ 
								"<tr><td></br> Insuredcity: " + "</td><td colspan='3'>"+ rs.getString(3)+"</td>"+"</tr>"+
								"<tr><td></br> Insured state: " + "</td><td colspan='3'>"+ rs.getString(4)+ "</td>"+"</tr>"+
								"<tr><td></br> insuredZip: " + "</td><td colspan='3'>"+ rs.getInt(5)+ "</td>"+"</tr>"+
								"<tr><td></br> Businesssegment: " + "</td><td colspan='3'>"+ rs.getString(6)+ "</td>"+"</tr>"+
								"<tr><td></br> Accountnumber: " + "</td><td colspan='3'>"+ rs.getInt(7)+ "</td>"+"</tr>"+
								
								" <tr><td></br>Questionid: " + "</td><td colspan='3'>"+ rs.getInt(8) + "</td>"+
								
								
								"<tr><td></br> question1: "+ "</td><td>"+ rs.getString(9) + "</td><td>"+ " Weightage1: " +"</td><td>"+ rs.getString(10)+"</td></tr>"+
								"<tr><td></br> question2: " + "</td><td>"+ rs.getString(11)+ "</td><td>"+" Weightage2: " +"</td><td>"+ rs.getString(12)+ "</td></tr>"+
								"<tr><td></br> question3: " + "</td><td>"+ rs.getString(13)+ "</td><td>"+" Weightage3: " + "</td><td>"+rs.getString(14)+ "</td></tr>"+
								"<tr><td></br> question4: " + "</td><td>"+ rs.getString(15)+ "</td><td>"+" Weightage4: " +"</td><td>"+ rs.getString(16)+ "</td></tr>"+
								"<tr><td></br> question5: " + "</td><td>"+ rs.getString(17)+ "</td><td>"+" Weightage5: " +"</td><td>"+ rs.getString(18)+ "</td></tr>"+
								"<tr><td></br> question6: " + "</td><td>"+ rs.getString(19)+ "</td><td>"+" Weightage6: " + "</td><td>"+rs.getString(20)+ "</td></tr>"+
								"<tr><td></br> question7: " + "</td><td>"+ rs.getString(21)+ "</td><td>"+" Weightage7: " + "</td><td>"+rs.getString(22)+"</td></tr>"+
								"<tr><td></br> question8: " + "</td><td>"+ rs.getString(23)+ "</td><td>"+" Weightage8: " + "</td><td>"+rs.getString(24)+"</td></tr>"+
								 "</table>" + "</body>" + "</html>");
				
			}
			ResultSet rs1 = ps1.executeQuery();
			 
			while (rs1.next()) 
			{
				out.println("</br>Premium:"+rs1.getInt(1));
			}
			out.println("</br></br><a href='Admin.jsp'>Return to admin</a>");
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			out.close();
		}
		System.out.println("retrieved data");
	
	}
	
	
}