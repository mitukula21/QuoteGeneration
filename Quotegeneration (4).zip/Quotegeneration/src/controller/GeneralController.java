package controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import services.GeneralService;
import services.RestaurantService;
 
public class GeneralController extends HttpServlet
{
 
	public  void doGet(HttpServletRequest request,HttpServletResponse response) 
	   throws ServletException,IOException 
	{
		RequestDispatcher rd = null;
		RequestDispatcher req = null;
		String businessType="";
		 String assetValue="";
		 String inflammableObjects="";
		 String popertySize="";
		 String propertyDamage="";
		 String bodilyInjury="";
		 String assetTheftLimit="";
		 String liablityCoverage="";
 
		 int account_number=0;
		String business_segment="";
 
 
		businessType=request.getParameter("BusinessType");
 
		assetValue=request.getParameter("AssetValue");
 
		inflammableObjects=request.getParameter("InflammableObjects");
		popertySize=request.getParameter("PopertySize");
 
		propertyDamage=request.getParameter("PropertyDamage");
		bodilyInjury=request.getParameter("BodilyInjury");
		assetTheftLimit=request.getParameter("AssetTheftLimit");
		liablityCoverage=request.getParameter("LiablityCoverage");
 
 
		 String account_number1=request.getParameter("account_number");
		 account_number=Integer.parseInt(account_number1);
 
 
 
 
 
 
 
 
 
 
 
			/*String insured_zip1=request.getParameter("insured_zip");
			insured_zip=Integer.parseInt(insured_zip1);*/
		 GeneralService bookService = new GeneralService();
 
 
 
		   int updateCount = bookService.addStudentService(businessType,assetValue,inflammableObjects,popertySize,propertyDamage,bodilyInjury,assetTheftLimit,liablityCoverage,account_number);
 
				System.out.println("inserted "+updateCount+" record   Success");
 
				if (updateCount==1)
				{
					rd = request.getRequestDispatcher("/Admin.jsp");	
 
				} else 
				{
					rd = request.getRequestDispatcher("/error.jsp");	
				}
				rd.forward(request, response);
			}
 
 
 
}