package controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import services.AccountService;
import services.BusinessService;

public class PolicyController extends HttpServlet
{
	
	public  void doGet(HttpServletRequest request,HttpServletResponse response) 
	   throws ServletException,IOException 
	{
		RequestDispatcher rd = null;
		RequestDispatcher req = null;
		
		String business_segment="";
		
		
		
		
		
		 business_segment=request.getParameter("business_segment");
		 try 
		    {

		        String page = request.getParameter("business_segment");



		        if(request.getParameter("business_segment").equals("BusinessAuto"))
		        {

		            request.setAttribute("s1", page);
		            req= getServletContext().getRequestDispatcher("/BusinessAuto.jsp");
		            req.forward(request, response);
		        }
		        else if(request.getParameter("business_segment").equals("Apartment"))
		        {
		            request.setAttribute("s2", page);
		             req = getServletContext().getRequestDispatcher("/Apartment.jsp");
		            req.forward(request, response);
		        }
		        else if(request.getParameter("business_segment").equals("Restaurant"))
		        {
		            request.setAttribute("s3", page);
		             req = getServletContext().getRequestDispatcher("/Restaurant.jsp");
		            req.forward(request, response);
		        }
		        else if(request.getParameter("business_segment").equals("General_Merchant"))
		        {
		            request.setAttribute("s3", page);
		             req = getServletContext().getRequestDispatcher("/General_Merchant.jsp");
		            req.forward(request, response);
		        }


		    } 
		    finally 
		    {
		       System.out.println("Succes");
		   
		    }
		
		
		
		
		
		
		
		
		/* vehicletype=request.getParameter("vehicletype");
		 
		 vehiclemy=request.getParameter("vehiclemy");
		 
		 vehiclemodel=request.getParameter("vehiclemodel");
		 dailycd=request.getParameter("dailycd");
		 servicecenter=request.getParameter("servicecenter");
		 limit=request.getParameter("limit");
		 limit2=request.getParameter("limit2");
		 String account_number1=request.getParameter("account_number");
		 account_number=Integer.parseInt(account_number1);
		
		 
		
		 
		 
		 
		 
		 
		 
		 
		 
			String insured_zip1=request.getParameter("insured_zip");
			insured_zip=Integer.parseInt(insured_zip1);
		 BusinessService bookService = new BusinessService();
			
			
			
		   int updateCount = bookService.addStudentService(vehicletype,vehiclemy,vehiclemodel,dailycd,servicecenter,limit,limit2,account_number);
				
				System.out.println("inserted "+updateCount+" record   Success");
				
				if (updateCount==1)
				{
					System.out.println("inserted succesfully");
					
				} else 
				{
					System.out.println(" not inserted succesfully");
				}
				//rd.forward(request, response);
			}
		 */

	}
}