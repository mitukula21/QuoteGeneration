package com.nag;

public class GeneralBean
{
	private String businessType;
	private String assetValue;
	private String inflammableObjects;
	private String popertySize;
	private String propertyDamage;
	private String bodilyInjury;
	private String assetTheftLimit;
	private String liablityCoverage;
 
	private int account_number;
 
	public String getBusinessType() {
		return businessType;
	}
 
	public void setBusinessType(String businessType) {
		this.businessType = businessType;
	}
 
	public String getAssetValue() {
		return assetValue;
	}
 
	public void setAssetValue(String assetValue) {
		this.assetValue = assetValue;
	}
 
	public String getInflammableObjects() {
		return inflammableObjects;
	}
 
	public void setInflammableObjects(String inflammableObjects) {
		this.inflammableObjects = inflammableObjects;
	}
 
	public String getPopertySize() {
		return popertySize;
	}
 
	public void setPopertySize(String popertySize) {
		this.popertySize = popertySize;
	}
 
	public String getPropertyDamage() {
		return propertyDamage;
	}
 
	public void setPropertyDamage(String propertyDamage) {
		this.propertyDamage = propertyDamage;
	}
 
	public String getBodilyInjury() {
		return bodilyInjury;
	}
 
	public void setBodilyInjury(String bodilyInjury) {
		this.bodilyInjury = bodilyInjury;
	}
 
	public String getAssetTheftLimit() {
		return assetTheftLimit;
	}
 
	public void setAssetTheftLimit(String assetTheftLimit) {
		this.assetTheftLimit = assetTheftLimit;
	}
 
	public String getLiablityCoverage() {
		return liablityCoverage;
	}
 
	public void setLiablityCoverage(String liablityCoverage) {
		this.liablityCoverage = liablityCoverage;
	}
 
	public int getAccount_number() {
		return account_number;
	}
 
	public void setAccount_number(int account_number) {
		this.account_number = account_number;
	}
 
 
 
 
}