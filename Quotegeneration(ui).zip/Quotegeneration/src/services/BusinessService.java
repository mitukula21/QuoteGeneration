package services;

import com.nag.AccountBean;
import com.nag.BusinessBean;


import dao.BusinessDAO;

public class BusinessService 
{
	
	
	//String vehicletype,String vehiclemy,String vehiclemodel,String dailycd,String servicecenter,String limit,String limit2

	public int addStudentService(String vehicletype,String vehiclemy,String vehiclemodel,String dailycd,String servicecenter,String limit,String limit2,int account_number)
	 {
		
		 
		BusinessDAO bookDAO = new  BusinessDAO();
		 BusinessBean businessBean = new BusinessBean();
		 //wrap up all the four field values into bean
		 
		 businessBean.setVehicletype(vehicletype);
		 businessBean.setVehiclemy(vehiclemy);
		 businessBean.setVehiclemodel(vehiclemodel);
		 businessBean.setDailycd(dailycd);
		 businessBean.setServicecenter(servicecenter);
		 businessBean.setLimit(limit);
		 businessBean.setLimit2(limit2);
		 businessBean.setAccount_number(account_number);
		 int updateResult = 0;
		 try
		 {
			 updateResult = BusinessDAO.addStudent1(businessBean);
			 return updateResult;
		 }
		 catch(Exception ex)
		 {
			 System.out.println(ex.toString());
			 return 0;
		 }
	 }
}
