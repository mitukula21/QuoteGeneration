package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
 
import com.nag.GeneralBean;
 
 
public class GeneralDAO
{
 
 
	  public static int addStudent1(GeneralBean bean)
	  {
		  Connection con = null;
		  PreparedStatement pstmt = null;
		  try
		  {
 
			  con=AccountDB.getConnection(); 
			 /* String sqk="SELECT questionid.currVAL from dual";
			  pstmt = con.prepareStatement(sqk);
			  pstmt.executeQuery();*/
			  String ins_str = 
				  "insert into General_Merchant values(questionid.nextVAL,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
 
			  pstmt = con.prepareStatement(ins_str);
			  String q1="Business Type";
			  String q2="Asset Value";
			  String q3="Inflammable Objects";
			  String q4="Poperty Size";
			  String q5="Property Damage";
			  String q6="Bodily Injury";
			  String q7="Asset Theft Limit";
			  String q8="Liablity Coverage";
 
 
 
 
 
			  pstmt.setString(1,q1);
			  pstmt.setString(2,bean.getBusinessType());
 
			  pstmt.setString(3,q2);
			  pstmt.setString(4,bean.getAssetValue());
			  pstmt.setString(5,q3);
 
			  pstmt.setString(6,bean.getInflammableObjects());
			  pstmt.setString(7,q4);
			  pstmt.setString(8,bean.getPopertySize());
			  pstmt.setString(9,q5);
			  pstmt.setString(10,bean.getPropertyDamage());
			  pstmt.setString(11,q7);
			  pstmt.setString(12,bean.getBodilyInjury());
			  pstmt.setString(13,q6);
			  pstmt.setString(14,bean.getAssetTheftLimit());
			  pstmt.setString(15,q8);
			  pstmt.setString(16,bean.getLiablityCoverage());
 
 
			  pstmt.setInt(17,bean.getAccount_number());
 
 
 
			  int updateCount = pstmt.executeUpdate();
 
			  con.close();
 
			  return updateCount;
 
 
		  }
		  catch(Exception ex)
		  {
			  System.out.println(ex.toString());
			  return 0;
		  }
 
	  }
	}