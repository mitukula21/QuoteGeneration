package services;

import com.nag.RestaurantBean;


import dao.RestaurantDAO;
 
public class RestaurantService 
{
	//restauranttype,restaurantSQFt,NumberofSprinklers,NoofCylindersinKitchen,FineArts,PropertyDamage,EquipmentBreakdown,LiablityCoverage,BodilyInjury
 
	//String vehicletype,String vehiclemy,String vehiclemodel,String dailycd,String servicecenter,String limit,String limit2
 
	public int addStudentService(String restauranttype,String restaurantSQFt,String numberofSprinklers,String noofCylindersinKitchen,String fineArts,String propertyDamage,String equipmentBreakdown,String liablityCoverage,String bodilyInjury,int account_number)
	 {
 
 
		RestaurantDAO bookDAO = new  RestaurantDAO();
		 RestaurantBean businessBean = new RestaurantBean();
		 //wrap up all the four field values into bean
 
		 businessBean.setRestauranttype(restauranttype);
		 businessBean.setRestaurantSQFt(restaurantSQFt);
		 businessBean.setNumberofSprinklers(numberofSprinklers);
		 businessBean.setNoofCylindersinKitchen(noofCylindersinKitchen);
		 businessBean.setFineArts(fineArts);
		 businessBean.setPropertyDamage(propertyDamage);
		 businessBean.setEquipmentBreakdown(equipmentBreakdown);
		 businessBean.setLiablityCoverage(liablityCoverage);
		 businessBean.setBodilyInjury(bodilyInjury);
		 businessBean.setAccount_number(account_number);
		 int updateResult = 0;
		 try
		 {
			 updateResult = RestaurantDAO.addStudent1(businessBean);
			 return updateResult;
		 }
		 catch(Exception ex)
		 {
			 System.out.println(ex.toString());
			 return 0;
		 }
	 }
}
